var mongoose = require('mongoose'); // an Ooject Data Modeling (ODM) library for MongoDB and Node.js
const chalk = require("chalk"); // terminal string styling

// connecting the database
mongoose.connect('mongodb://localhost/HP', {
	useMongoClient: true
});

// setting variable for database connection
var db = mongoose.connection;

// display error if error occurs or message to console log if connected
db.on('error', console.error.bind(console, 'connect error:'));
db.once('open', function() {
	console.log(`${chalk.green("✓")} Connected to ${chalk.green("MongoDB")} Store`);
})

// user schema
var UserSchema = mongoose.Schema({
	username: {
		type: String,
		index: true
	},
	password: {
		type: String,
		required: true,
		bcrypt: true
	},
	email: String,
	name: String,
	profile: String
});

// module exports for model user
module.exports = mongoose.model('User', UserSchema);