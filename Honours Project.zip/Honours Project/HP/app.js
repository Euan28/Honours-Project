// dependencies, these are in the package.json, showing the versions that we have used
var express = require('express'); // fast, minimalist web framework (server) for node
var path = require('path'); // provides utilities for working with file and directory path
var favicon = require('serve-favicon'); // Node.js middleware for serving a favicon
var logger = require('morgan'); // HTTP request logger middleware for Node.js
var expressValidator = require('express-validator'); // an express.js middleware for validator
var exphbs = require('express-handlebars');
var cookieParser = require('cookie-parser'); // a middleware which parses cookies attached to the client request object
var bodyParser = require('body-parser'); // extract the entire body portion of an incoming request stream and exposes it on req
var session = require('express-session'); // simple session middleware for express
var passport = require('passport'); // authentication middleware for Node.js
var localStrategy = require('passport-local').Strategy; // passport strategy for authenticating with a username and password
var multer = require('multer'); // a Node. js middleware for handling multipart/form-data , which is primarily used for uploading files
var flash = require('connect-flash'); //  flash message middleware
var mongo = require('mongodb'); // a cross-platform document-oriented NoSQL database program
var mongoose = require('mongoose'); // an Object Data Modeling (ODM) library for MongoDB and Node.js
var db = mongoose.connection; // setting variable for database connection

// declaring routes folder and files
var routes = require('./routes/index');
var users = require('./routes/routes');

var app = express(); // setting variable for server

// view engine setup, setting up how we view the .hbs by using the 'views' folder
// setting the engine to hbs
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs'); // setting up the view engine as Handlebars (hbs)
app.engine(
	'hbs',
	exphbs({
	  extname: 'hbs', // Handlebars files used in this engine setup
	  layoutsDir: path.join(__dirname, 'views', 'layouts'), // link to layouts folder
	  partialsDir: path.join(__dirname, 'views', 'partials'), // link to partials folder
	  defaultLayout: 'main',
	})
  );

// to serve audio, images, JavaScript, Scripts, Stylesheets and SCSS/CSS in a directory named public
app.use(express.static(path.join(__dirname, 'public')));

// handling file uploads such as creating a new account
app.use(multer({
	dest: __dirname + '/uploads/'
}).any());

// uncomment after placing your favicon in /public
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: false
}));

// handling express sessions
app.use(session({
	secret: 'secret',
	saveUninitialized: true,
	resave: true
}));

// middle-ware that initialises passport and acts as a middleware to alter the req object and change the 'user' value that is currently the session id (from the client cookie) into the true deserialized user object
app.use(passport.initialize());
app.use(passport.session());

// express validator 
app.use(expressValidator({
	errorFormator: function(param, msg, value) {
		var namespace = param.split('.'),
			root = namespace.shift(),
			formParam = root;
		while (namespace.length) {
			formParam += '[' + namespace.shift() + ']';
		}
		return {
			param: formParam,
			msg: msg,
			value: value
		};
	}
}));

// express cookie parser middleware
app.use(cookieParser());

// flash express messages
app.use(flash());
app.use(function(req, res, next) {
	res.locals.messages = require('express-messages')(req, res);
	next();
});

app.get('*', function(req, res, next) {
	//local variable to hold user info
	res.locals.user = req.user || null;
	next();
});

// uses the routes folder files
app.use('/', routes);
app.use('/HP', users);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
	var err = new Error('Not Found');
	err.status = 404;
	next(err);
});

// error handler
app.use(function(err, req, res, next) {
	// set locals, only providing error in development
	res.locals.message = err.message;
	res.locals.error = req.app.get('env') === 'development' ? err : {};
	// render the error page
	res.status(err.status || 500);
	res.render('error');
});

// the module.exports property or the exports object allows a module to select what should be shared with the application
module.exports = app;