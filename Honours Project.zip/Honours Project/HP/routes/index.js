var express = require('express'); // fast, minimalist web framework (server) for node
var router = express.Router(); // setting the router to that of express

// members page
router.get('/', ensureAuthenticated, function(req, res, next) {
	res.render('index', {
		title: 'Home'
	});
});

function ensureAuthenticated(req, res, next) {
	if (req.isAuthenticated()) {
		return next();
	}
	req.flash('error', 'You have to Login First.'); // if user is not authenticated, the server will send the user to the home page
	res.redirect('/HP/home');
}

// module exports for model user
module.exports = router;