const fetch = require("node-fetch");

const params = {
    api_key: '6HnsWdRyNz9NHaK2amw26R2CbIPDgdE1RibjzQgw',
    query: 'chicken',
    dataType: ["Survey (FNDDS)"],
    pagesize: 5,
}

const api_url =
`https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${encodeURIComponent(params.api_key)}&query=${encodeURIComponent(params.query)}&dataType=${encodeURIComponent(params.dataType)}&pageSize=${encodeURIComponent(params.pagesize)}`

function getData() {
    return fetch(api_url).then(response => response.json())
} 

// in order to retrieve food/or nutrirional data, cd HP, cd routes, node get

// get food information on query value = chicken
// getData().then(data => console.log(data))

// get nutritional information on food, if you use the get below, you will have to get rid of the one above
 getData().then(data => console.log(data.foods[0].foodNutrients))