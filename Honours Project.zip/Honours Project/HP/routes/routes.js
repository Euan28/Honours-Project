var express = require('express'); // fast, minimalist web framework (server) for node
var router = express.Router();
var User = require('../models/user'); // uses the user file in the models folder
var bcrypt = require('bcrypt'); // a library to help you hash passwords
var passport = require('passport'); // authentication middleware for Node.js
var localStrategy = require('passport-local').Strategy; // passport strategy for authenticating with a username and password

// default
router.get('/', function(req, res, next) {
	res.send('Respond with a resource');
});

// renders the home page
router.get('/home', function(req, res, next) {
	res.render('home', {
		layout: 'home.hbs',
		'title': 'Home'
	});
});

// renders the about page
router.get('/about', function(req, res, next) {
	res.render('about', {
		'title': 'About'
	});
});

// renders the info page
router.get('/info', function(req, res, next) {
	res.render('info', {
		'title': 'Info'
	});
});

// renders the contact page
router.get('/contact', function(req, res, next) {
	res.render('contact', {
		layout: 'home.hbs',
		'title': 'Contact'
	});
});

// renders the login page
router.get('/login', function(req, res, next) {
	res.render('login', {
		'title': 'Login'
	});
});

// renders the forgot password page
router.get('/forgotpassword', function(req, res, next) {
	res.render('forgotpassword', {
		'title': 'Forgot Password'
	});
});

// renders the register page
router.get('/register', function(req, res, next) {
	res.render('register', {
		'title': 'Register'
	});
});

// renders the privacy page
router.get('/privacy', function(req, res, next) {
	res.render('privacy', {
		'title': 'Privacy'
	});
});

// renders the disclaimer page
router.get('/disclaimer', function(req, res, next) {
	res.render('disclaimer', {
		'title': 'Disclaimer'
	});
});

// renders the pomodoro page
router.get('/pomodoro', function(req, res, next) {
	res.render('pomodoro', {
		'title': 'Pomodoro'
	});
});

// renders the bmi page
router.get('/bmi', function(req, res, next) {
	res.render('bmi', {
		'title': 'Bmi'
	});
});

// renders the get started page
router.get('/getstarted', function(req, res, next) {
	res.render('getstarted', {
		'title': 'Get Started'
	});
});

// renders the get started page
router.get('/workoutplan', function(req, res, next) {
	res.render('workoutplan', {
		'title': 'Workout Plan'
	});
});

// renders the results page
router.get('/results', function(req, res, next) {
	res.render('results', {
		'title': 'Results'
	});
});

// renders the calendar page
router.get('/calendar', function(req, res, next) {
	res.render('calendar', {
		'title': 'Calendar'
	});
});

// renders the services page
router.get('/services', function(req, res, next) {
	res.render('services', {
		'title': 'Services'
	});
});

// renders the nutrition page
router.get('/nutrition', function(req, res, next) {
	res.render('nutrition', {
		'title': 'Nutrition'
	});
});

// renders the musclegroups page
router.get('/musclegroups', function(req, res, next) {
	res.render('musclegroups', {
		'title': 'Muscle Groups'
	});
});

// post function for registering a user 
router.post('/register', function(req, res, next) {

	// get Form Values
	var name = req.body.name;
	var email = req.body.email;
	var username = req.body.username;
	var password = req.body.password;
	var confirmPassword = req.body.confirmPassword;

	// check for image field
	if (req.files.length != 0) {
		console.log('uploading');
		var profileImageOriginalName = req.files[0].originalname;
		var profileImageName = req.files[0].originalname
		var profileImageMime = req.files[0].mimeType;
		var profileImagePath = req.files[0].path;
		var profileImageSize = req.files[0].size;
	} else {
		// set a default image else
		var profileImageName = 'noImage.png';
	}

	// form validation using express-validator
	req.checkBody('name', 'Name Field is Required').notEmpty();
	req.checkBody('email', 'Email Field is Required').notEmpty();
	req.checkBody('email', 'Email not Valid').isEmail();
	req.checkBody('username', 'Username Field is Required').notEmpty();
	req.checkBody('password', 'Password Field is Required').notEmpty();
	req.checkBody('confirmPassword', 'Passwords do not Match').equals(req.body.password);
	
	// check for errors
	var errors = req.validationErrors();
	if (errors) {
		res.render('register', {
			errors: errors,
			name: name,
			email: email,
			username: username,
			password: password,
			confirmPassword: confirmPassword
		});
	} else {
		// creating a modal for a new user
		var newUser = new User({
			name: name,
			email: email,
			username: username,
			password: password,
			profile: profileImageName
		});
		// create user
		console.log(newUser);
		// setting the salted password
		var salt = 10;
		bcrypt.hash(newUser.password, salt, function(err, hash) {
			if (err) throw err;
			// set hashed password
			newUser.password = hash;
			// create new user
			newUser.save(newUser, function(err, user) {
				if (err) throw err;
				console.log(user);
			});
			// success message
			req.flash('success', 'You are now registered and may log in');
			res.location('/');
			res.redirect('/');
		});
	}
});

// flow (IV) [passport creating a session for current logged in user by serialising it.]
passport.serializeUser(function(user, done) {
	done(null, user[0].id);
});

// deserialiing user 
passport.deserializeUser(function(id, done) {
	User.findById(id, function(err, user) {
		done(err, user);
	});
});

// flow (III)
var comparePassword = function(candidatePassword, hash, callback) {
	bcrypt.compare(candidatePassword, hash, function(err, isMatch) {
		if (err) return callback(err);
		callback(null, isMatch);
	});
}

// flow (II)
passport.use(new localStrategy(function(username, password, done) {
	User.find({
		username: username
	}, function(err, user) {
		if (err) throw err;
		if (user.length == 0) {
			console.log('Unknown User');
			return done(null, false, {
				message: 'Unknown User'
			});
		}
		comparePassword(password, user[0].password, function(err, isMatch) {
			if (err) throw err;
			if (isMatch) {
				return done(null, user);
				res.redirect('/');
			} else {
				console.log('Invalid Password');
				return done(null, false, {
					message: 'Invalid Password'
				});
			}
		})
	});
}));

//flow (I)
router.post('/login', passport.authenticate('local', {
	failureRedirect: '/HP/login',
	failureFlash: 'Invalid Username or Password'
}), function(req, res) {
	// if local strategy comes true
	console.log('Authentication Successful');
	req.flash('success', 'You are Logged In');
	res.redirect('/HP/home');
});

// logging out
router.get('/logout', function(req, res) {
	req.logout();
	req.flash('success', 'You have logged out');
	res.redirect('/HP/login');
});

// the module.exports property or the exports object allows a module to select what should be shared with the application
module.exports = router;