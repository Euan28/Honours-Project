cd to directory in terminal after npm installing all of the dependencies 
nodemon ./bin/www